package com.example.proyecto;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity2 extends AppCompatActivity{// implements Response.Listener<JSONObject>, Response.ErrorListener {
    RequestQueue rq;
    String url;
    JsonObjectRequest jor;
    EditText txt;
    Button btnMostrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        txt = (EditText) findViewById(R.id.multiLineText);
        btnMostrar = (Button) findViewById(R.id.btnMostrar);


        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClickView(view);
            }
        });

    }
    public void btnClickView(View view){
        rq = Volley.newRequestQueue(this);
        url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=1&clave=23049741";

        jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        rq.add(jor);

    }
    @Override
    public void onErrorResponse(VolleyError error) {
        Log.e("Conexión:","Error al conectar, ptm");
    }

    @Override
    public void onResponse(JSONObject response) {
        Log.e("Conexion","Conectó");

        JSONArray json = response.optJSONArray("dato");

        JSONObject jo = null;

        try{
            String nombre="";
            for(int i = 0; i<json.length();i++){
                jo = json.getJSONObject(i);
                nombre += jo.optString("nom")+"\n";
            }
            txt.setText(nombre);

        }catch (Exception e){
            Log.e("Exception","Nosepqperoexception");
        }*/
    }
}