package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class EliminarContacto extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    Button btnEliminar, btnCancelar, btnBuscarID;
    EditText editTextID,editTextNombre, editTextApellido,editTextTelefono;
    Boolean existe=false,busqueda=false;
    RequestQueue rq;
    String url;
    JsonObjectRequest jor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar_contacto);

        btnEliminar = (Button) findViewById(R.id.btnEliminarContacto);
        btnCancelar = (Button) findViewById(R.id.btnCancelarElim);
        btnBuscarID = (Button) findViewById(R.id.btnBuscarIDElim);


        editTextNombre = (EditText) findViewById(R.id.editTextNombreElim);
        editTextApellido = (EditText) findViewById(R.id.editTextApellidoElim);
        editTextTelefono = (EditText) findViewById(R.id.editTextTelefonoElim);
        editTextID = (EditText) findViewById(R.id.editTextIDContElim);
        editTextNombre.setEnabled(false);
        editTextApellido.setEnabled(false);
        editTextTelefono.setEnabled(false);


        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!editTextID.getText().toString().equals(""))
                {
                    eliminarContacto(view);
                    Toast.makeText(EliminarContacto.this, "Contacto eliminado", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(EliminarContacto.this, "Use un ID válido", Toast.LENGTH_SHORT).show();

                }

            }
        });

        btnBuscarID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buscarID(view);
            }
        });



    }
    public void clear(View view){
        editTextTelefono.setText("");
        editTextNombre.setText("");
        editTextID.setText("");
        editTextApellido.setText("");
    }
    public void eliminarContacto(View view){
        if(busqueda){
            String ID = editTextID.getText().toString();
            rq = Volley.newRequestQueue(this);

            url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=4"
                    +"&id="+ID+"&clave=23049741";

            jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

            rq.add(jor);
            clear(view);
            busqueda = false;
        }else{
            buscarID(view);
        }
    }
    public void buscarID(View view){
        busqueda = true;
        rq = Volley.newRequestQueue(this);
        url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=1&clave=23049741";

        jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        rq.add(jor);
        busqueda = true;
    }
    public String comprobar(String str){
        String vals = "'\"-;:()*";
        for(char b:vals.toCharArray()){
            str = str.replace(String.valueOf(b),"");
        }
        return str;
    }

    @Override
    public void onErrorResponse(VolleyError error) {

    }

    @Override
    public void onResponse(JSONObject response) {
        Log.e("Conexion","Conectó");
        String mensaje = "",idTemp="";

        JSONArray json = response.optJSONArray("dato");

        JSONObject jo = null;

        try{
            String nombre="";
            for(int i = 0; i<json.length();i++){
                jo = json.getJSONObject(i);
                idTemp = jo.optString("id");
                if(idTemp.equals(comprobar(editTextID.getText().toString()))){
                    editTextTelefono.setText(jo.optString("tel"));
                    editTextApellido.setText(jo.optString("app"));
                    editTextNombre.setText(jo.optString("nom"));
                    existe=true;
                }else{
                    existe = false;
                }
            }
            Log.e("BuscarID", mensaje+"");

        }catch (Exception e){
            Log.e("Exception","Nosepqperoexception");
        }
    }
}