package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class AgregarContacto extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    RequestQueue rq;
    String url;
    JsonObjectRequest jor;
    Integer index;

    String indice="";
    Button btnAgregar,btnCancelar;
    EditText editTextNombre,editTextApellido,editTextTel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_contacto);

        btnAgregar = (Button) findViewById(R.id.btnAgregarC);
        btnCancelar = (Button) findViewById(R.id.btnCancelarAgregar);

        editTextNombre = (EditText) findViewById(R.id.editTextNombreAgregar);
        editTextApellido = (EditText) findViewById(R.id.editTextApellidoAgregar);
        editTextTel = (EditText) findViewById(R.id.editTextTelefonoAgregar);

        rq = Volley.newRequestQueue(this);

        url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=1&clave=23049741";
        jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        rq.add(jor);


        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre,apellido,telefono;
                nombre = comprobar(editTextNombre.getText().toString());
                telefono = comprobar(editTextTel.getText().toString());
                apellido = comprobar(editTextApellido.getText().toString());
                if(!nombre.equals("") &&  !telefono.equals("")) {
                    if(apellido.equals("")) apellido = "SnApellido";
                    agregarContacto(view);

                    Toast.makeText(AgregarContacto.this, "Contacto agregado", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(AgregarContacto.this, "Nombre y campos no pueden estar vacíos", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void onErrorResponse(VolleyError error) {

    }
    public String comprobar(String str){
        String vals = "'\"-;:()*";
        for(char b:vals.toCharArray()){
            str = str.replace(String.valueOf(b),"");
        }
        return str;
    }
    @Override
    public void onResponse(JSONObject response) {
        Log.e("Conexion","Conectó");
        String mensaje = "",idTemp="";

        JSONArray json = response.optJSONArray("dato");

        JSONObject jo = null;

        try{
            for(int i = 0; i<json.length();i++){
                jo = json.getJSONObject(i);
                indice = jo.optString("id");
            }
            Log.e("BuscarID", mensaje+"");

        }catch (Exception e){
            Log.e("Exception","Nosepqperoexception");
        }
    }
    public void clear(View view){
        editTextTel.setText("");
        editTextNombre.setText("");
        editTextApellido.setText("");
    }
    public void agregarContacto(View view){
        index = Integer.valueOf(indice);
        index +=1;
        String nombre,apellido,telefono;
        nombre = editTextNombre.getText().toString();
        telefono = editTextTel.getText().toString();
        apellido = editTextApellido.getText().toString();

        rq = Volley.newRequestQueue(this);

        url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=2"+
                "&id="+index+
                "&nom="+nombre+
                "&tel="+telefono+
                "&app="+apellido+
                "&clave=23049741";

        jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        rq.add(jor);
        clear(view);

    }
}