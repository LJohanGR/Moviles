package com.example.proyecto;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {
    ArrayList<String> IDs,Nombres,Apellidos,Telefonos;

    public AdapterDatos(ArrayList IDs, ArrayList Nombres, ArrayList Apellidos, ArrayList Telefonos){
        this.IDs=IDs;
        this.Nombres=Nombres;
        this.Apellidos=Apellidos;
        this.Telefonos=Telefonos;
    }

    @NonNull
    @Override
    public AdapterDatos.ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_lista,null,false);
        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterDatos.ViewHolderDatos holder, int position) {
        holder.asignarDatos(IDs.get(position),Nombres.get(position),Apellidos.get(position),Telefonos.get(position));
    }

    @Override
    public int getItemCount() {
        return IDs.size()   ;
    }

    public class ViewHolderDatos extends  RecyclerView.ViewHolder{
        TextView id, nombre, apellido, telefono;
        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            id = itemView.findViewById(R.id.textViewIDItems);
            nombre = itemView.findViewById(R.id.textViewNombreItems);
            apellido = itemView.findViewById(R.id.textViewApellidoItems);
            telefono = itemView.findViewById(R.id.textViewTelefonoItem);
        }

        public void asignarDatos(String ID,String Nombre,String Apellido,String Telefono) {
            id.setText(ID);
            nombre.setText(Nombre);
            apellido.setText(Apellido);
            telefono.setText(Telefono);
        }
    }
}
