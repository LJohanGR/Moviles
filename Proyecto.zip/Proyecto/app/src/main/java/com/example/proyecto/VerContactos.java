package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class VerContactos extends AppCompatActivity  implements Response.Listener<JSONObject>, Response.ErrorListener {
    ArrayList<String> IDs = new ArrayList<String>(),Nombres= new ArrayList<String>(),Apellidos= new ArrayList<String>(),Telefonos= new ArrayList<String>();
    Button btnRegresar;
    RecyclerView recyclerView;

    RequestQueue rq;
    String url;
    JsonObjectRequest jor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_contactos);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewElementos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        rq = Volley.newRequestQueue(this);
        url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=1&clave=23049741";
        jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);
        rq.add(jor);

        /*
        IDs = consultarIDs();
        Nombres = consultarNombres();
        Apellidos = consultarApellidos();
        Telefonos = consultarTelefonos();
        */
        //obtenerDatos();
        /*
        Log.e("Ciclos","Aqui inician los ciclos");
        for(int i = 0;i<IDs.size();i++){
            Log.e("Ciclo ID", IDs.get(i)+"");
        }*/
        btnRegresar = (Button) findViewById(R.id.btnRegresarLista);




        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void agregar(String id, String nombre, String telefono, String apellido){
        IDs.add(id);
        Log.e("Tamano IDs",""+IDs.size());
    }
    @Override
    public void onErrorResponse(VolleyError error) {

    }

    @Override
    public void onResponse(JSONObject response) {
        Log.e("Conexion","Conectó");
        String mensaje = "",idTemp="",nombre="",apellido="",telefono="",id="";

        JSONArray json = response.optJSONArray("dato");

        JSONObject jo = null;

        try{
            for(int i = 0; i<json.length();i++){
                jo = json.getJSONObject(i);
                idTemp += jo.optString("id") +","+ jo.optString("nom") +","+ jo.optString("tel") +","+jo.optString("app");


                IDs.add(jo.optString("id"));
                Nombres.add(jo.optString("nom"));
                Telefonos.add(jo.optString("tel"));
                Apellidos.add(jo.optString("app"));
                //agregar(id,nombre,telefono,apellido);


/*
                id = jo.optString("id");
                nombre = jo.optString("nom");
                telefono = jo.optString("tel");
                apellido = jo.optString("app");
                agregar(id,nombre,telefono,apellido);
*/

                Log.e("BuscarID", idTemp+"");
                idTemp = "";
            }
                for(int i = 0;i<IDs.size();i++){
                    Log.e("Ciclo ID", IDs.get(i)+"");}
            AdapterDatos adapterDatos = new AdapterDatos(IDs,Nombres,Apellidos,Telefonos);
            recyclerView.setAdapter(adapterDatos);
            Log.e("BuscarID", mensaje+"");

        }catch (Exception e){
            Log.e("Exception",e.getMessage());
        }
    }
}