package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class ModificarContactos extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    Button btnModif, btnCancelar, btnBuscarID;
    EditText editTextID,editTextNombre, editTextApellido,editTextTelefono;
    Boolean existe=false,busqueda=false;
    RequestQueue rq;
    String url;
    JsonObjectRequest jor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_contactos);

        btnModif = (Button) findViewById(R.id.btnModificarContacto);
        btnCancelar = (Button) findViewById(R.id.btnCancelarMod);
        btnBuscarID = (Button) findViewById(R.id.btnBuscarIDMod);


        editTextNombre = (EditText) findViewById(R.id.editTextNombreMod);
        editTextApellido = (EditText) findViewById(R.id.editTextApellidoMod);
        editTextTelefono = (EditText) findViewById(R.id.editTextTelefonoMod);
        editTextID = (EditText) findViewById(R.id.editTextIDContMod);

        btnModif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btnBuscarID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buscarID(view);
            }
        });
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btnModif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!editTextID.getText().toString().equals("") && !editTextNombre.getText().toString().equals("") && !editTextTelefono.getText().toString().equals(""))
                {
                    modificarContacto(view);
                    Toast.makeText(ModificarContactos.this, "Contacto modificado", Toast.LENGTH_SHORT).show();

                }
                else{
                    Toast.makeText(ModificarContactos.this, "Rellene campos id, nombre y telefono", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    public String comprobar(String str){
        String vals = "'\"-;:()*";
        for(char b:vals.toCharArray()){
            str = str.replace(String.valueOf(b),"");
        }
        return str;
    }
    public void modificarContacto(View view) {
        String nombre, telefono, apellido, id;
        Boolean nomCheck, telCheck, apellidoCheck,idCheck;

        id = editTextID.getText().toString();
        nombre = comprobar(editTextNombre.getText().toString());
        telefono = comprobar(editTextTelefono.getText().toString());
        apellido = comprobar(editTextApellido.getText().toString());
        if(!busqueda){

        }
        if(!id.equals("")){
            if(nombre.equals("")) nomCheck=false; else nomCheck=true;
            if(telefono.equals("")) telCheck=false; else telCheck=true;
            if(apellido.equals("")) apellidoCheck=false; else apellidoCheck=true;

            buscarID(view);
            if (existe) {
                if(!nomCheck) editTextNombre.setText(nombre);else nombre = editTextNombre.getText().toString();
                if(!telCheck) editTextTelefono.setText(telefono);else telefono = editTextTelefono.getText().toString();
                if(!apellidoCheck) editTextApellido.setText(apellido);else apellido = editTextApellido.getText().toString();
                rq = Volley.newRequestQueue(this);

                url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=3" +
                        "&id=" + id +
                        "&nom=" + nombre +
                        "&tel=" + telefono +
                        "&app=" + apellido +
                        "&clave=23049741";

                jor = new JsonObjectRequest(Request.Method.GET, url, null, this, this);

                rq.add(jor);
                clear(view);
            }else{

            }
        }


    }
    public void clear(View view){
        editTextTelefono.setText("");
        editTextNombre.setText("");
        editTextApellido.setText("");
        editTextID.setText("");
    }
    public void buscarID(View view){
        rq = Volley.newRequestQueue(this);
        url = "https://serviciosdigitalesplus.com/servicio/servicio.php?tipo=1&clave=23049741";

        jor = new JsonObjectRequest(Request.Method.GET,url,null,this,this);

        rq.add(jor);
        busqueda = true;
    }

    @Override
    public void onErrorResponse(VolleyError error) {

    }

    @Override
    public void onResponse(JSONObject response) {
        Log.e("Conexion","Conectó");
        String mensaje = "",idTemp="";

        JSONArray json = response.optJSONArray("dato");

        JSONObject jo = null;

        try{
            String nombre="";
            for(int i = 0; i<json.length();i++){
                jo = json.getJSONObject(i);
                idTemp = jo.optString("id");
                if(idTemp.equals(editTextID.getText().toString())){
                    editTextTelefono.setText(jo.optString("tel"));
                    editTextApellido.setText(jo.optString("app"));
                    editTextNombre.setText(jo.optString("nom"));
                    existe=true;
                }else{
                    existe = false;
                }
            }
            Log.e("BuscarID", mensaje+"");

        }catch (Exception e){
            Log.e("Exception","Nosepqperoexception");
        }
    }
}