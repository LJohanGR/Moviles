package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {
    Button btnCrear, btnModif, btnElim, btnVer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btnVer = (Button) findViewById(R.id.btnMostrar);
        btnCrear = (Button) findViewById(R.id.btnCrear);
        btnModif = (Button) findViewById(R.id.btnModificarC);
        btnElim = (Button) findViewById(R.id.btnEliminarC);

        btnVer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verContactos(view);
            }
        });
        btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregarContactos(view);
            }
        });
        btnModif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modificarContactos(view);
            }
        });
        btnElim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminarContactos(view);
            }
        });
    }
    public void verContactos(View view) {
        Intent i = new Intent(this,VerContactos.class);
        startActivity(i);
    }
    public void agregarContactos(View view) {
        Intent i = new Intent(this,AgregarContacto.class);
        startActivity(i);
    }
    public void modificarContactos(View view) {
        Intent i = new Intent(this,ModificarContactos.class);
        startActivity(i);
    }
    public void eliminarContactos(View view) {
        Intent i = new Intent(this,EliminarContacto.class);
        startActivity(i);
    }
}